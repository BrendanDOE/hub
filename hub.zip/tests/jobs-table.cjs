const vm=require('node:vm'),fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
(async()=>{
const saved=new Map();const events={};let active=false,renders=0;
const style={width:'160px',setProperty(k,v){this[k]=v}};
const col={dataset:{columnWidth:'Subject'},style};
const handle={dataset:{resizeColumn:'Subject'},attrs:{},setAttribute(k,v){this.attrs[k]=v},setPointerCapture(){},hasPointerCapture(){return false}};
const table={style:{},querySelectorAll:s=>s.startsWith('col')?[col]:[handle]};
const root={addEventListener(type,fn){events[type]=fn},querySelector:()=>table,querySelectorAll:()=>[]};
const context=vm.createContext({console,localStorage:{getItem:k=>saved.get(k)||null,setItem:(k,v)=>saved.set(k,v)},window:{addEventListener(){}},document:{addEventListener(){},body:{classList:{add(){},remove(){}}}}});
const mod=new vm.SourceTextModule(fs.readFileSync(path.join(__dirname,'../assets/js/jobs-table.js'),'utf8'),{context});await mod.link(()=>{});await mod.evaluate();const {sortJobs,clampWidth,JobsTable}=mod.namespace;
const rows=[{number:10,subject:'job 10',copies:'100',dueDate:'2026-11-02',attachments:[{name:'file10.pdf'}]},{number:2,subject:'Job 2',copies:'9',dueDate:'2026-10-25',attachments:[{name:'file2.pdf'}]},{number:3,subject:'',copies:'',dueDate:'',attachments:[]}];
for(const field of ['Subject','Copies','Due date','Attachments']){assert.equal(sortJobs(rows,field)[0].number,2);assert.equal(sortJobs(rows,field,'desc')[0].number,10);assert.equal(sortJobs(rows,field,'desc')[2].number,3);}
assert.deepEqual(Array.from(sortJobs(rows,'ID'),j=>j.number),[2,3,10]);assert.equal(rows[0].number,10);assert.equal(clampWidth(10),80);assert.equal(clampWidth(1000),800);
const options={render:()=>renders++,onActive:v=>active=v};const controls=new JobsTable(root,options);
controls.toggleSort('ID');assert.equal(controls.sort.direction,'asc');controls.toggleSort('ID');assert.equal(controls.sort.direction,'desc');assert.equal(renders,2);
const event={target:{closest:()=>handle},button:0,pointerId:4,clientX:100,preventDefault(){},stopPropagation(){}};
controls.start(event);assert(active);controls.move({...event,clientX:180});assert.equal(style.width,'360px');controls.end(event);assert(!active);assert.equal(controls.width('Subject'),360);
controls.start(event);controls.move({...event,clientX:250});controls.cancel();assert.equal(style.width,'360px');assert.equal(controls.width('Subject'),360);
const restored=new JobsTable(root,options);assert.equal(restored.width('Subject'),360);assert.equal(restored.sort.column,'ID');assert.equal(restored.sort.direction,'desc');
events.keydown({target:{closest:()=>handle},key:'ArrowRight',shiftKey:true,preventDefault(){}});assert.equal(restored.width('Subject'),380);
events.click({target:{closest:s=>s==='[data-resize-column]'?handle:null}});assert.equal(renders,2);
console.log('PASS: natural alphanumeric sorting, numeric IDs, blanks last, descending order, source preservation, sort toggle, resize drag, cancellation, bounds, keyboard resize, saved widths/sort, and resize click exclusion.');
})().catch(e=>{console.error(e);process.exit(1)});
