// Run with node --experimental-vm-modules tests/jobs.cjs. No browser dependencies.
const vm=require('node:vm'),fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
(async()=>{
const state={section:'jobs',settings:{automaticRefresh:true},jobs:[]};
const nodes=new Map(); const $=s=>{if(!nodes.has(s))nodes.set(s,{innerHTML:'',textContent:'',hidden:false});return nodes.get(s)};
const escapeHtml=(s='')=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let requestCount=0,conflict=false,dialog=false;const api={setJobStatus:async(j,status)=>{if(conflict)throw Error('Conflict');return {...j,status,revision:j.revision+1}},bootstrap:async()=>{requestCount++;return {jobs:[],tiles:[{id:'fresh'}],settings:{theme:'other'}}}};
const context=vm.createContext({console,Date,Map,setTimeout,clearTimeout,setInterval,document:{hidden:false,querySelector:()=>dialog?{}:null}});
const stub=(values)=>new vm.SyntheticModule(Object.keys(values),function(){for(const [k,v]of Object.entries(values))this.setExport(k,v)},{context});
const shared=stub({state,$,$$:()=>[],escapeHtml,els:{},THEME_KEY:'test',ENABLE_CALENDAR_MODULE:true,favicon:()=>'',normalizeUrl:x=>x});
const feature=stub({Feature:class{constructor(services){this.services=services}}});const apiModule=stub({api});
const dragModule=new vm.SourceTextModule(fs.readFileSync(path.join(__dirname,'../assets/js/jobs-drag.js'),'utf8'),{context});await dragModule.link(()=>{});await dragModule.evaluate();
const tableModule=new vm.SourceTextModule(fs.readFileSync(path.join(__dirname,'../assets/js/jobs-table.js'),'utf8'),{context});await tableModule.link(()=>{});await tableModule.evaluate();
const prefs=stub({STEPPER_PREFERENCES:{},normalizePreference:(k,v)=>v});
async function load(name){const mod=new vm.SourceTextModule(fs.readFileSync(path.join(__dirname,'../assets/js',name),'utf8'),{context});await mod.link(s=>s.includes('jobs-table.js')?tableModule:s.includes('jobs-drag.js')?dragModule:s.includes('context.js')?shared:s.includes('feature.js')?feature:s.includes('preferences.js')?prefs:apiModule);await mod.evaluate();return mod.namespace;}
const {Jobs}=await load('jobs.js');const services={application:{toast:()=>{}}};const jobs=new Jobs(services);services.jobs=jobs;jobs.root={hidden:false,innerHTML:'',classList:{add(){},remove(){}},querySelector:()=>null,querySelectorAll:()=>[]};
state.jobs=[{id:'one',number:1,subject:'<script>unsafe</script>',requester:'Display',assignedTo:'Brian',status:'Pending',priority:'High',dueDate:'2000-01-01',createdAt:'2026-10-20',updatedAt:'2026-10-20',revision:1,jobType:'Print',attachments:[]},{id:'two',number:2,subject:'Complete',status:'Complete',dueDate:'2000-01-01',createdAt:'2026-10-20',updatedAt:'2026-10-20'}];
assert.equal(jobs.items.filter(j=>jobs.matches(j,'Overdue')).length,1);jobs.query='display';assert.equal(jobs.filtered.length,1);jobs.query='';
assert(!jobs.table(state.jobs,true).includes('<script>'));assert(jobs.table(state.jobs,true).includes('data-job-row="one" tabindex="0"'));assert(jobs.table(state.jobs,false).includes('class="job-cell-content"'));assert.equal((jobs.table(state.jobs,true).match(/<th scope/g)||[]).length,18);assert.equal((jobs.board(state.jobs).match(/class="job-lane"/g)||[]).length,4);assert.equal((jobs.schedule(state.jobs).match(/class="job-day /g)||[]).length,7);
jobs.filter='On Hold';assert.equal(jobs.filtered.length,0);
for(const view of ['list','status','schedule']){jobs.view=view;assert.equal(jobs.filtered.length,2);jobs.render();assert(jobs.root.innerHTML.includes('jobs-body--full'));assert(jobs.root.innerHTML.includes('aria-label="Filter jobs" hidden'));}
jobs.view='overview';assert.equal(jobs.filtered.length,0);jobs.filter='All Jobs';
jobs.hiddenColumns.overview=['Requester','Status'];assert.equal((jobs.table(state.jobs,false).match(/<th scope/g)||[]).length,4);assert.equal((jobs.table(state.jobs,true).match(/<th scope/g)||[]).length,18);
jobs.hiddenColumns.list=['Description','Attachments'];assert.equal((jobs.table(state.jobs,true).match(/<th scope/g)||[]).length,16);jobs.hiddenColumns.overview=['Subject','Requester','Assigned to','Due date','Priority','Status'];assert.equal(jobs.visibleColumns('overview').length,1);
jobs.view='schedule';jobs.scheduleMode='month';const monthly=jobs.schedule(state.jobs);const count=(monthly.match(/class="job-day /g)||[]).length;assert([28,35,42].includes(count));assert.equal((monthly.match(/class="job-weekday"/g)||[]).length,7);assert(monthly.includes('Previous month'));assert(monthly.includes('data-schedule-mode="month" aria-pressed="true"'));
// Exercise February and December/January navigation, with jobs on month boundaries.
const now=new Date();jobs.month=(2028-now.getFullYear())*12+1-now.getMonth();assert(jobs.schedule([{...state.jobs[0],subject:'Leap day job',dueDate:'2028-02-29'}]).includes('Leap day job'));
jobs.month=(2026-now.getFullYear())*12+11-now.getMonth();assert(jobs.schedule([]).includes('December 2026'));jobs.month++;assert(jobs.schedule([]).includes('January 2027'));
jobs.view='overview';assert.equal((jobs.schedule([]).match(/class="job-day /g)||[]).length,7);jobs.hiddenColumns={};
await jobs.changeStatus(state.jobs[0],'In Progress');assert.equal(state.jobs.find(j=>j.id==='one').status,'In Progress');conflict=true;await jobs.changeStatus(state.jobs.find(j=>j.id==='one'),'Complete');assert.equal(state.jobs.find(j=>j.id==='one').status,'In Progress');assert.equal(jobs.busy,false);
const {Application}=await load('application.js');services.editor={registerFontFaces:()=>{}};services.board={layoutTiles:()=>{}};const app=new Application(services);app.renderAll=()=>{};state.settings.theme='midnight';await app.refreshData();assert.equal(requestCount,1);assert.equal(state.tiles[0].id,'fresh');assert.equal(state.settings.theme,'midnight');dialog=true;await app.refreshData();assert.equal(requestCount,1);dialog=false;state.settings.automaticRefresh=false;await app.refreshData();assert.equal(requestCount,1);state.settings.automaticRefresh=true;jobs.busy=true;await app.refreshData();assert.equal(requestCount,1);
console.log('PASS: Jobs filters, overdue exclusion, search, escaped output, full list columns, four lanes, weekly/monthly schedules, leap-year and year navigation, view-specific filters, column visibility, status success/conflict, refresh data, local settings preservation, and edit/disabled/busy refresh guards.');
})().catch(e=>{console.error(e);process.exit(1)});
