// Isolated pointer lifecycle tests; no browser or live user data required.
const vm=require('node:vm'),fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
class Node {
 constructor(name,rect={left:0,top:0,width:260,height:150}){this.name=name;this.rect=rect;this.children=[];this.style={};this.dataset={};this.listeners={};this.classes=new Set();this.classList={add:(...s)=>s.forEach(x=>this.classes.add(x)),remove:(...s)=>s.forEach(x=>this.classes.delete(x)),toggle:(s,on)=>on?this.classes.add(s):this.classes.delete(s)};}
 addEventListener(type,fn){this.listeners[type]=fn;}
 getBoundingClientRect(){return {...this.rect,right:this.rect.left+this.rect.width,bottom:this.rect.top+this.rect.height};}
 append(n){this.insertBefore(n,null);}
 insertBefore(n,next){n.remove();n.parentElement=this;const i=next?this.children.indexOf(next):this.children.length;this.children.splice(i,0,n);}
 before(n){this.parentElement.insertBefore(n,this);}
 remove(){if(this.parentElement)this.parentElement.children=this.parentElement.children.filter(x=>x!==this);this.parentElement=null;}
 get nextElementSibling(){const a=this.parentElement?.children||[];return a[a.indexOf(this)+1]||null;}
 contains(n){return n===this || this.children.some(c=>c.contains(n));}
 closest(selector){if(selector==='.job-lane' && this.name==='lane')return this;if(selector==='.job-card' && this.name==='card')return this;return this.parentElement?.closest(selector)||null;}
 querySelector(s){if(s==='.jobs-board')return board;if(s==='.job-lane-cards')return this.children.find(c=>c.name==='list');return null;}
 querySelectorAll(s){let a=[];for(const c of this.children){if((s==='.job-lane' && c.name==='lane') || (s.includes('.job-card') && c.name==='card' && !c.classes.has('is-pointer-dragging')) || (s==='.is-drop-target' && c.classes.has('is-drop-target')))a.push(c);a.push(...c.querySelectorAll(s));}return a;}
 cloneNode(){return new Node('ghost',this.rect);}
 removeAttribute(){} setAttribute(){} setPointerCapture(){} hasPointerCapture(){return false;}
 getAnimations(){return [];}
 animate(frames,options){this.animation={frames,options};return {finished:Promise.resolve(),cancel(){}};}
}
let target=null,active=null,drops=[],enabled=true;const body=new Node('body'),root=new Node('root'),board=new Node('board',{left:0,top:0,width:1000,height:600});board.scrollLeft=0;root.append(board);
const lanes=['Pending','In Progress'].map((status,i)=>{const n=new Node('lane',{left:i*300,top:0,width:280,height:600});n.dataset.status=status;const list=new Node('list');n.append(list);board.append(n);return n;});
const items=[{id:'a',number:1,dueDate:'2026-10-24',status:'Pending'},{id:'b',number:2,dueDate:'2026-10-25',status:'In Progress'}];
function card(job,lane){const c=new Node('card');c.dataset.job=job.id;lane.children[0].append(c);return c;}const a=card(items[0],lanes[0]),b=card(items[1],lanes[1]);
const doc={body,addEventListener(){},createElement:()=>new Node('slot'),elementFromPoint:()=>target};
const win={addEventListener(){},matchMedia:()=>({matches:false}),scrollBy(){},innerHeight:800};
const ctx=vm.createContext({document:doc,window:win,requestAnimationFrame:()=>1,cancelAnimationFrame(){},console});
(async()=>{const m=new vm.SourceTextModule(fs.readFileSync(path.join(__dirname,'../assets/js/jobs-drag.js'),'utf8'),{context:ctx});await m.link(()=>{});await m.evaluate();const {JobsDrag,compareJobOrder}=m.namespace;
assert(compareJobOrder(items[0],items[1])<0);
const drag=new JobsDrag(root,{items:()=>items,canStart:()=>enabled,onActive:id=>active=id,onDrop:async(job,status)=>drops.push({id:job.id,status})});
const event=(x,y=80)=>({target:a,pointerId:1,button:0,isPrimary:true,clientX:x,clientY:y,preventDefault(){}});
drag.down(event(50));drag.move(event(54));assert.equal(active,null);drag.up(event(54));assert.equal(drops.length,0);
drag.down(event(50));drag.move(event(70));assert.equal(active,'a');assert.equal(body.children.length,1);target=lanes[1];drag.frame(16);assert.equal(drag.session.slot.parentElement,lanes[1].children[0]);assert.equal(drag.session.slot.nextElementSibling,b);assert(lanes[1].classes.has('is-drop-target'));const ghost=drag.session.ghost;await drag.up(event(350));assert.equal(drops.length,1);assert.equal(drops[0].status,'In Progress');assert.equal(ghost.animation.options.duration,220);assert.equal(body.children.length,0);assert.equal(active,null);
// Invalid drop and Escape leave persisted state untouched and clean up every node.
drag.down(event(50));drag.move(event(80));target=null;await drag.up(event(1100));assert.equal(drops.length,1);assert.equal(active,null);
drag.down(event(50));drag.move(event(80));drag.key({key:'Escape',preventDefault(){}});assert.equal(active,null);assert.equal(body.children.length,0);
enabled=false;drag.down(event(50));assert.equal(drag.session,null);enabled=true;
drag.down(event(50));drag.move({...event(80),pointerId:9});assert.equal(active,null);drag.cancel();
const button={closest:s=>s==='.job-card'?a:{}};drag.down({...event(50),target:button});assert.equal(drag.session,null);
console.log('PASS: pointer threshold, capture lifecycle, target placement matching due order, animated ghost landing, successful drop, invalid drop, Escape, busy guard, pointer identity, and edit-button exclusion.');
})().catch(e=>{console.error(e);process.exit(1)});
